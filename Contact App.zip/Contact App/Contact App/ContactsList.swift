//
//  ContactsList.swift
//  Contact App
//
//  Created by bmiit on 3/28/22.
//

import UIKit
class ContactsList{
    	var contactList=[Contact]()
}
