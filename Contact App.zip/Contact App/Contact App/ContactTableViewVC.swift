import UIKit
import CoreData


class ContactTableViewVC:UITableViewController{
    var contacts=[Contact]()
//    var contacts:[Contact]=[]
    var firsLoad = true
    @IBAction func toggleEditingMode(_ sender: UIButton) {
        if isEditing {
            // Change text of button to inform user of state
            sender.setTitle("Edit", for: .normal)
            // Turn off editing mode
            setEditing(false, animated: true)
        } else {
            // Change text of button to inform user of state
            sender.setTitle("Done", for: .normal)
            // Enter editing mode
            setEditing(true, animated: true)
        }
    }
    
    @IBAction func addNewItem(_ sender: UIButton) {
        // Make a new index path for the 0th section, last row
        let lastRow = tableView.numberOfRows(inSection: 0)
        let indexPath = IndexPath(row: lastRow, section: 0)
        // Insert this new row into the table
        tableView.insertRows(at: [indexPath], with: .automatic)
    }
    
    
    override func viewDidLoad() {
        if(firsLoad){
            firsLoad = false
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Contact")
            tableView.rowHeight = UITableView.automaticDimension
            do{
                let results:NSArray = try context.fetch(request) as NSArray
                for result in results {
                    let contact = result as! Contact
                    contacts.append(contact)
                }
            }
            catch{
                print("Fetch failed")
            }
        }
        super.viewDidLoad()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contactCell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath)
        let thisContact: Contact!
        thisContact = contacts[indexPath.row]
        
        contactCell.textLabel?.text = thisContact.name
        //        contactCell.lblPhoneNumber.text = thisContact.phoneNumber
        return contactCell
    }
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
}
