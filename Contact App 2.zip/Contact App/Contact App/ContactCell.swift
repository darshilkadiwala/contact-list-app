import UIKit

class ContactCell: UITableViewCell{
    @IBOutlet var lblName: UILabel!
    @IBOutlet var lblPhoneNumber: UILabel!
}
