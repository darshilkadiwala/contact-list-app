import UIKit
import CoreData
class ContactDetailVC: UIViewController {

    @IBOutlet var txtName: UITextField!
    @IBOutlet var txtPhoneNumber: UITextField!
    @IBOutlet var btnSaveContact: UIBarButtonItem!
    @IBAction func saveContactAction(_ sender: UIBarButtonItem) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
        let entity = NSEntityDescription.entity(forEntityName: "Contact", in: context)
        let newContact = Contact(entity: entity!, insertInto: context )
        newContact.id = contactsList.count as NSNumber
        newContact.name = txtName.text ?? "DFDFD"
        newContact.phoneNumber = txtPhoneNumber.text ?? "1111"
        do{
            try context.save()
            contactsList.append(newContact)
            navigationController?.popViewController(animated: true)
        }
        catch{
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
