import UIKit
import CoreData

var contactsList = [Contact]()
class ContactTableViewVC:UITableViewController{
    
    var firsLoad = true
    override func viewDidLoad() {
        if(firsLoad){
            firsLoad = false
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context: NSManagedObjectContext = appDelegate.persistentContainer.viewContext
            let request = NSFetchRequest<NSFetchRequestResult>(entityName: "Contact")
            
            do{
                let results:NSArray = try context.fetch(request) as NSArray
                for result in results {
                    let contact = result as! Contact
                    contactsList.append(contact)
                }
            }
            catch{
                
            }
        }
        super.viewDidLoad()
    }
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactsList.count
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let contactCell = tableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath)as! ContactCell
        let thisContact: Contact!
        thisContact = contactsList[indexPath.row]
        
        contactCell.lblName.text = thisContact.name
        contactCell.lblPhoneNumber.text = thisContact.phoneNumber
        print(thisContact.name)
        print(thisContact.phoneNumber)
        return contactCell
    }
    override func viewDidAppear(_ animated: Bool) {
        tableView.reloadData()
    }
}
